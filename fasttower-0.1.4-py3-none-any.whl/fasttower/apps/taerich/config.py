from fasttower.apps.config import AppBaseConfig


class AppConfig(AppBaseConfig):
    app = 'aerich'
    db = 'default'
