from fasttower.apps.config import AppBaseConfig


class AppConfig(AppBaseConfig):
    app = 'fasttower.auth'
    db = 'default'
