from fastapi import APIRouter

__all__ = [
    'APIRouter',
]
