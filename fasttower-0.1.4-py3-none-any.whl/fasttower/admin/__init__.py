from fasttower.admin import site

__all__ = [
    'site',
]
