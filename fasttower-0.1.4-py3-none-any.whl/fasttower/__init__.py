from fastapi import FastAPI as FastTower


__all__ = [
    'FastTower',
]
